Python Version: 3.10
Anaconda: NIL
Packages:
- Pandas
- matplotlib
	